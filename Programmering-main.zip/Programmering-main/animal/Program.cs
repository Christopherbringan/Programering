﻿using System;

namespace animal
{
    class Program
    {
        static void Main(string[] args)
        {
            Zoo djurpark = new Zoo();
            djurpark.Run();
        }
    }
}
