using System;

namespace interface1
{
    interface Shape3D
    {
        double GetArea();
        double GetVolume();
    }
}