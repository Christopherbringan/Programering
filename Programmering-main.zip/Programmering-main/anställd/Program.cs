﻿using System;

namespace Anställd1
{
    class Program
    {
        static void Main(string[] args)
        {
            Test anställda = new Test();
            anställda.Run();
        
        }
    }
}

