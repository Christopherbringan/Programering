using System;

namespace arv
{

    class Cat
    {

        private int age;

       public Cat(int age1)
       {
           age = age1;
       }

       public void Act()
       {
         Console.WriteLine("Mjau" + age);

       }
    }
}