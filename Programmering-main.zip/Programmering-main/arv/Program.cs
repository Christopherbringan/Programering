﻿using System;

namespace arv
{
    class Program
    {
        static void Main(string[] args)
        {
             Zoo djurpark = new Zoo();
             djurpark.Run();
                
        }

    }
}
