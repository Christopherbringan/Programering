using System;
using System.Collections.Generic;

namespace arv_sak
{
    abstract class Sak
    {
        protected string title;

        public abstract void Act();
      
        
      
    }
}