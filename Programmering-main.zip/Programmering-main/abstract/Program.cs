﻿using System;

namespace arv_sak
{
    class Program
    {
        static void Main(string[] args)
        {
            Databas databas = new Databas();
            
        }
    }
}
